<div class="xoo-el-uv-cont">
	<span><i class="far fa-smile"></i></span>
	<span><?php _e("Thank you for signing up. We need to verify your email address. Please check your inbox." ,'easy-login-woocommerce'); ?></span>
</div>