<?php
/**
 * Plugin Uninstallation
 * 
 * Fired when the plugin is uninstallad
 * 
 */

if ( ! defined( 'WP_UNINSTALL_PLUGIN' ) ) exit();
