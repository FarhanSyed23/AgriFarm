<?php
/**
 * Nothing here
 *
 * @package BDPaymentGateways
 */

// Silence is golden.
